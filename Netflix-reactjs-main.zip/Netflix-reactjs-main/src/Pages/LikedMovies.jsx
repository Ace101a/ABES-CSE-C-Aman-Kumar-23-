import React from "react";
import UserMovieSection from "../componets/UserMovieSection/UserMovieSection";

function LikedMovies() {
  return <UserMovieSection from="LikedMovies"></UserMovieSection>;
}

export default LikedMovies;
